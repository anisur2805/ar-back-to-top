=== AR Back To Top ===
Contributors: anisur8294
Tags: ar back to top, back to top, scroll top, smooth scroll,
Requires at least: 4.7
Tested up to: 5.0.3
Requires PHP: 5.2
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

AR Back To Top is a standard WordPress plugin for back to top. 

== Description ==
AR Back To Top plugin will help them who don\'t wants to write code. For use this plugin simply download or add new plugin from WordPress plugin directory.

Features


Displays a button when user scrolls down the page.

You can set the position when button will show

Scrolls the page back to top with smooth animation.

You can choose variety scroll top Font Awesome button( v_4.7 ).

Set any button background color you want.

Set any button color you want.

Set any button position you want.



== Installation ==
The Installation process is below 


Click Add New -> Plugins from the WordPress admin panel.

Search for �AR Back To Top� and install.


-or-

Download the .zip package from WordPress Repository.

Unzip and upload your website plugin directory.

Refresh plugin page and Activate plugin.

Configure plugin from admin dashboard AR Back To Top menu.



== Frequently Asked Questions ==
For any questions, error reports and suggestions please email anisur2805@gmail.com

== Screenshots ==
1. Set your setting
2. How its look like