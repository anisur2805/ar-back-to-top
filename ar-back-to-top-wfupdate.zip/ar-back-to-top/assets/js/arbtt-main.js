/*global jQuery, $ */
jQuery(document).ready(function ($) {
"use strict";
 $('#arbtt_bgc, #arbtt_clr, #arbtt_bdclr').minicolors();
});